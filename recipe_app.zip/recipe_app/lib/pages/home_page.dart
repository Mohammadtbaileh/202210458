// lib/pages/home_page.dart

// Core Flutter material design library for building UI.
import 'package:flutter/material.dart';
// Firebase Authentication library for managing user sessions (e.g., current user, logout).
import 'package:firebase_auth/firebase_auth.dart';
// Firebase Firestore for database operations (fetching and managing recipes).
import 'package:cloud_firestore/cloud_firestore.dart';

// Import custom pages for navigation within the app.
import 'package:recipe_app/pages/login_page.dart'; // For logging out and navigating back to login.
import 'package:recipe_app/pages/add_recipes.dart'; // For adding or editing recipes.
import 'package:recipe_app/pages/about_us_page.dart'; // Link to the About Us page.
import 'package:recipe_app/pages/settings_page.dart'; // Link to the Settings page.
import 'package:recipe_app/pages/profile_page.dart'; // Link to the Profile page.

/// A StatefulWidget representing the main home page of the Recipe Book application.
/// It displays a list of recipes and provides navigation to other parts of the app.
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

/// The State class for HomePage.
class _HomePageState extends State<HomePage> {
  // Firebase Authentication instance to get the current user.
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // Firebase Firestore instance to interact with the 'recipes' collection.
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    // Get the currently logged-in user from Firebase Auth.
    User? currentUser = _auth.currentUser;

    return Scaffold(
      // AppBar for the home page.
      appBar: AppBar(
        title: const Text('Recipe Book'), // Title of the app bar.
        centerTitle: true, // Centers the title.
      ),
      // Drawer (side navigation menu) for global app navigation.
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero, // Remove default padding for the ListView in Drawer.
          children: <Widget>[
            // UserAccountsDrawerHeader displays user information in the drawer header.
            UserAccountsDrawerHeader(
              // Display the current user's display name, defaulting to 'Guest'.
              accountName: Text(currentUser?.displayName ?? 'Guest'),
              // Display the current user's email, defaulting to a placeholder.
              accountEmail: Text(currentUser?.email ?? 'guest@example.com'),
              // Display the user's profile picture or a default icon.
              currentAccountPicture: CircleAvatar(
                backgroundColor: Theme.of(context).colorScheme.secondary, // Uses the secondary color for background.
                // Conditionally display NetworkImage if photoURL exists, otherwise null.
                backgroundImage: currentUser?.photoURL != null
                    ? NetworkImage(currentUser!.photoURL!) // Loads image from Firebase Auth photoURL.
                    : null,
                // If no photoURL, display a default person icon.
                child: currentUser?.photoURL == null
                    ? const Icon(Icons.person, size: 40, color: Colors.white)
                    : null,
              ),
              // Decoration for the drawer header, using the primary theme color.
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            // Home option in the drawer.
            ListTile(
              leading: const Icon(Icons.home), // Icon for home.
              title: const Text('Home'), // Text for home.
              onTap: () {
                Navigator.pop(context); // Close the drawer.
                // No navigation needed as we are already on the home page.
              },
            ),
            // Add Recipe option in the drawer.
            ListTile(
              leading: const Icon(Icons.add_circle), // Icon for add recipe.
              title: const Text('Add Recipe'), // Text for add recipe.
              onTap: () {
                Navigator.pop(context); // Close the drawer.
                // Navigate to the AddRecipes page.
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AddRecipes()),
                );
              },
            ),
            // Settings option in the drawer.
            ListTile(
              leading: const Icon(Icons.settings), // Icon for settings.
              title: const Text('Settings'), // Text for settings.
              onTap: () {
                Navigator.pop(context); // Close the drawer.
                // Navigate to the SettingsPage.
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const SettingsPage()),
                );
              },
            ),
            // Profile option in the drawer.
            ListTile(
              leading: const Icon(Icons.person), // Icon for profile.
              title: const Text('Profile'), // Text for profile.
              onTap: () {
                Navigator.pop(context); // Close the drawer.
                // Navigate to the ProfilePage.
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProfilePage()),
                );
              },
            ),
            // About Us option in the drawer.
            ListTile(
              leading: const Icon(Icons.info), // Icon for about us.
              title: const Text('About Us'), // Text for about us.
              onTap: () {
                Navigator.pop(context); // Close the drawer.
                // Navigate to the AboutUsPage.
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AboutUsPage()),
                );
              },
            ),
            // Logout option in the drawer.
            ListTile(
              leading: const Icon(Icons.logout), // Icon for logout.
              title: const Text('Logout'), // Text for logout.
              onTap: () async {
                // Sign out the current user from Firebase.
                await _auth.signOut();
                // Check if the widget is still mounted before performing UI navigation.
                if (mounted) {
                  // Navigate to the LoginPage and remove all previous routes from the stack.
                  // This prevents the user from going back to HomePage using the back button.
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (context) => const LoginPage()),
                        (Route<dynamic> route) => false, // Predicate to remove all routes.
                  );
                }
              },
            ),
          ],
        ),
      ),
      // Body of the HomePage, displaying recipes.
      body: StreamBuilder<QuerySnapshot>(
        // Listen to real-time changes in the 'recipes' collection in Firestore.
        stream: _firestore.collection('recipes').snapshots(),
        builder: (context, snapshot) {
          // Show a circular progress indicator while data is loading.
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          // Display an error message if there's an error in the stream.
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          // If no data is available or the collection is empty, display a message.
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.restaurant_menu, size: 80, color: Colors.grey[400]), // A large icon.
                  const SizedBox(height: 16),
                  Text(
                    'No recipes added yet. Click the + button to add one!',
                    style: TextStyle(fontSize: 16, color: Colors.grey[600]),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );
          }

          // Extract the list of recipe documents from the snapshot.
          final recipes = snapshot.data!.docs;

          // Build a scrollable list of recipes using ListView.builder.
          return ListView.builder(
            itemCount: recipes.length, // Number of recipes.
            itemBuilder: (context, index) {
              final recipe = recipes[index]; // Current recipe document.
              // Safely get recipe data, providing fallback values if fields are null.
              final String recipeName = recipe['username'] ?? 'No Name';
              final String description = recipe['description'] ?? 'No description';
              final String? userId = recipe['userId'] as String?; // User ID who added the recipe.

              // Display each recipe as a Card.
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                elevation: 4.0, // Card shadow.
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)), // Rounded corners.
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start, // Align content to the start (left).
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween, // Space out content.
                        children: [
                          Expanded(
                            child: Text(
                              recipeName, // Display recipe name.
                              style: const TextStyle(
                                fontSize: 20.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          // Show edit/delete buttons only if the current user is the one who added the recipe.
                          if (currentUser != null && currentUser.uid == userId)
                            Row(
                              children: [
                                // Edit button.
                                IconButton(
                                  icon: const Icon(Icons.edit, color: Colors.blue),
                                  onPressed: () {
                                    // Navigate to AddRecipes page in editing mode.
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => AddRecipes(
                                          documentId: recipe.id, // Pass document ID for editing.
                                          userName: recipeName, // Pass existing name.
                                          description: description, // Pass existing description.
                                          isEditing: true, // Indicate editing mode.
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                // Delete button.
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  onPressed: () async {
                                    // Show a confirmation dialog before deleting.
                                    bool? confirmDelete = await showDialog<bool>(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        title: const Text('Delete Recipe'),
                                        content: const Text('Are you sure you want to delete this recipe?'),
                                        actions: <Widget>[
                                          TextButton(
                                            onPressed: () => Navigator.of(context).pop(false), // Cancel delete.
                                            child: const Text('Cancel'),
                                          ),
                                          TextButton(
                                            onPressed: () => Navigator.of(context).pop(true), // Confirm delete.
                                            child: const Text('Delete'),
                                          ),
                                        ],
                                      ),
                                    );

                                    // If user confirmed deletion.
                                    if (confirmDelete == true) {
                                      try {
                                        // Delete the recipe document from Firestore.
                                        await _firestore.collection('recipes').doc(recipe.id).delete();
                                        if (mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(content: Text('Recipe deleted successfully!'), backgroundColor: Colors.green),
                                          );
                                        }
                                      } catch (e) {
                                        // Handle errors during deletion.
                                        if (mounted) {
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(content: Text('Failed to delete recipe: $e'), backgroundColor: Colors.red),
                                          );
                                        }
                                      }
                                    }
                                  },
                                ),
                              ],
                            ),
                        ],
                      ),
                      const SizedBox(height: 10.0),
                      // Display recipe description.
                      Text(
                        description,
                        style: const TextStyle(fontSize: 16.0),
                      ),
                      // Indicate who added the recipe (You or Another User).
                      if (userId != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text(
                            'Added by ${userId == currentUser?.uid ? 'You' : 'Another User'}',
                            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
      // Floating Action Button for adding new recipes.
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Navigate to the AddRecipes page when the button is pressed.
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddRecipes()),
          );
        },
        tooltip: 'Add Recipe', // Tooltip for accessibility.
        child: const Icon(Icons.add), // Plus icon.
      ),
    );
  }
}