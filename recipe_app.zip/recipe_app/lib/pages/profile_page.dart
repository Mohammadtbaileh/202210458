// lib/pages/profile_page.dart

// Flutter's core material design library.
import 'package:flutter/material.dart';

// Firebase Firestore for database operations (saving/loading user profile data).
import 'package:cloud_firestore/cloud_firestore.dart';
// Firebase Authentication for user management (display name, password, email).
import 'package:firebase_auth/firebase_auth.dart';

// Import the login page for navigation after logout/password change.
import 'package:recipe_app/pages/login_page.dart';

/// A StatefulWidget for displaying and managing the user's profile information.
/// This page allows users to update their display name and change their password.
class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

/// The State class for ProfilePage.
class _ProfilePageState extends State<ProfilePage> {
  // Firebase Authentication instance to interact with user authentication.
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // Firebase Firestore instance to interact with the 'users' collection.
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // GlobalKey to uniquely identify the Form widget and enable form validation.
  final _formKey = GlobalKey<FormState>();

  // A convenience getter to get the current authenticated user from Firebase Auth.
  User? get currentUser => _auth.currentUser;

  // State variables to manage UI loading and error feedback.
  bool _isLoading = true; // Indicates if user profile data is being loaded.
  bool _isUpdating = false; // Indicates if profile or password update is in progress.
  String? _errorMessage; // Stores error messages to display to the user.

  // Variable to store the display name fetched from Firestore or Firebase Auth.
  String? _displayName;

  // Text editing controllers for input fields.
  final _displayNameController = TextEditingController(); // Controls the display name input.
  final _passwordController = TextEditingController(); // Controls the new password input.
  final _currentPasswordController =
  TextEditingController(); // Controls the current password input for reauthentication.

  @override
  void initState() {
    super.initState();
    // Load the user's profile data when the page is initialized.
    _loadUserProfile();
  }

  @override
  void dispose() {
    // Dispose of the text editing controllers to free up resources.
    _displayNameController.dispose();
    _passwordController.dispose();
    _currentPasswordController.dispose();
    super.dispose();
  }

  /// Loads the current user's profile data from Firestore or Firebase Auth.
  Future<void> _loadUserProfile() async {
    // If no user is logged in, set loading to false and show an error.
    if (currentUser == null) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'User not logged in.';
      });
      return;
    }

    try {
      // Attempt to fetch the user document from the 'users' collection in Firestore.
      final doc = await _firestore.collection('users').doc(currentUser!.uid).get();

      // If the document exists, retrieve the display name from Firestore.
      if (doc.exists) {
        final data = doc.data()!;
        setState(() {
          _displayName = data['displayName'] as String?;
          _displayNameController.text = _displayName ?? ''; // Set controller text
        });
      } else {
        // If no document exists in Firestore, use the display name from Firebase Auth.
        setState(() {
          _displayName = currentUser!.displayName;
          _displayNameController.text = _displayName ?? ''; // Set controller text
        });
      }
    } catch (e) {
      // Catch any errors during profile loading and display an error message.
      setState(() {
        _errorMessage = 'Failed to load profile: $e';
        print('Error loading profile: $e'); // Log the error for debugging
      });
    } finally {
      // Ensure loading state is set to false regardless of success or failure.
      setState(() {
        _isLoading = false;
      });
    }
  }

  /// Saves the updated display name to Firebase Firestore and Firebase Authentication.
  Future<void> _saveProfile() async {
    // Return if no user is logged in or form validation fails.
    if (currentUser == null) return;
    if (!_formKey.currentState!.validate()) return; // Validate form inputs

    setState(() {
      _isUpdating = true; // Set updating state to true to show loading indicator.
      _errorMessage = null; // Clear previous error messages.
    });

    try {
      // Update the 'users' collection in Firestore with the new display name.
      // SetOptions(merge: true) ensures that only specified fields are updated
      // and other existing fields in the document are preserved.
      await _firestore.collection('users').doc(currentUser!.uid).set(
        {
          'displayName': _displayNameController.text.trim(), // Trim whitespace from display name
          'email': currentUser!.email, // Keep email updated (though usually static)
          'lastUpdated': FieldValue.serverTimestamp(), // Record the last update time
        },
        SetOptions(merge: true),
      );

      // Update the display name directly in Firebase Authentication.
      await currentUser!.updateDisplayName(_displayNameController.text.trim());

      // Update local state variables to reflect the changes.
      setState(() {
        _displayName = _displayNameController.text.trim();
      });

      // Show a success message using a SnackBar.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated successfully!'), backgroundColor: Colors.green),
        );
      }
    } on FirebaseAuthException catch (e) {
      // Handle Firebase Authentication specific errors.
      if (mounted) {
        setState(() {
          _errorMessage = 'Authentication Error: ${e.message}';
        });
      }
    } catch (e) {
      // Handle any other general errors during profile update.
      if (mounted) {
        setState(() {
          _errorMessage = 'Failed to update profile: $e';
        });
      }
    } finally {
      // Always set updating state to false.
      setState(() {
        _isUpdating = false;
      });
    }
  }

  /// Reauthenticates the current user using their email and provided current password.
  /// This is required for sensitive operations like changing password.
  Future<AuthCredential?> _reauthenticateUser() async {
    if (currentUser == null) return null; // No user logged in.

    String currentPassword = _currentPasswordController.text.trim();
    // Validate if current password is provided.
    if (currentPassword.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter your current password for verification.'), backgroundColor: Colors.red),
        );
      }
      return null;
    }

    try {
      // Create an AuthCredential using the user's email and provided current password.
      AuthCredential credential = EmailAuthProvider.credential(
        email: currentUser!.email!,
        password: currentPassword,
      );

      // Attempt to reauthenticate the user with the credential.
      final UserCredential userCredential = await currentUser!.reauthenticateWithCredential(credential);

      // Show success message and return the credential if reauthentication is successful.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Reauthenticated successfully.'), backgroundColor: Colors.green),
        );
      }
      return credential;
    } on FirebaseAuthException catch (e) {
      // Handle specific Firebase Authentication errors during reauthentication.
      String message;
      if (e.code == 'wrong-password') {
        message = 'The current password you entered is incorrect.';
      } else if (e.code == 'user-not-found') {
        message = 'No user found for that email.';
      } else if (e.code == 'invalid-email') {
        message = 'The email address is not valid.';
      } else if (e.code == 'too-many-requests') {
        message = 'Too many failed login attempts. Please try again later.';
      } else {
        message = e.message ?? 'Reauthentication failed.';
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Reauthentication Error: $message'), backgroundColor: Colors.red),
        );
      }
      return null; // Return null if reauthentication fails.
    } catch (e) {
      // Handle any other general errors during reauthentication.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('An unexpected error during reauthentication: $e'), backgroundColor: Colors.red),
        );
      }
      return null; // Return null if reauthentication fails.
    }
  }

  /// Changes the user's password in Firebase Authentication.
  /// Requires reauthentication for security.
  Future<void> _changePassword() async {
    if (currentUser == null) return; // No user logged in.

    // Validate if the new password meets minimum length requirements.
    if (_passwordController.text.length < 6) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('New password must be at least 6 characters.'), backgroundColor: Colors.red),
        );
      }
      return;
    }

    setState(() {
      _isUpdating = true; // Set updating state.
      _errorMessage = null; // Clear previous error.
    });

    try {
      // First, reauthenticate the user. This is a security measure by Firebase.
      final credential = await _reauthenticateUser();

      // If reauthentication fails, stop the process.
      if (credential == null) {
        setState(() {
          _isUpdating = false;
        });
        return;
      }

      // Update the user's password with the new one.
      await currentUser!.updatePassword(_passwordController.text.trim());

      // Clear password fields after successful change.
      _passwordController.clear();
      _currentPasswordController.clear();

      // Show success message, log out the user, and navigate to the login page.
      // Firebase often requires re-login after password changes for security.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Password changed successfully! Please log in again with your new password.'),
              backgroundColor: Colors.green),
        );
        await _auth.signOut(); // Sign out the user
        // Navigate to LoginPage and remove all previous routes from the stack.
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LoginPage()),
              (Route<dynamic> route) => false,
        );
      }
    } on FirebaseAuthException catch (e) {
      // Handle specific Firebase Authentication errors during password change.
      if (mounted) {
        String message;
        if (e.code == 'weak-password') {
          message = 'The new password provided is too weak.';
        } else if (e.code == 'requires-recent-login') {
          message = 'This operation is sensitive and requires recent authentication. Please enter your current password.';
        } else {
          message = e.message ?? 'Failed to change password.';
        }
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Password change failed: $message'), backgroundColor: Colors.red),
        );
      }
    } catch (e) {
      // Handle any other general errors.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('An unexpected error occurred during password change: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      // Always set updating state to false.
      setState(() {
        _isUpdating = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Show a loading indicator if profile data is still being loaded.
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    // If no user is logged in after loading, display a message.
    if (currentUser == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Profile')),
        body: const Center(
          child: Text('You must be logged in to view your profile.'),
        ),
      );
    }

    // Main UI for the profile page.
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0), // Padding around the content.
        child: Form(
          key: _formKey, // Associate the form key with the Form widget.
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center, // Center contents horizontally.
            children: [
              // Display a static CircleAvatar with a person icon.
              // Image logic has been removed as per user request.
              CircleAvatar(
                radius: 60, // Size of the avatar.
                backgroundColor: Theme.of(context).primaryColor.withOpacity(0.2), // Background color with opacity.
                child: Icon(Icons.person, size: 60, color: Theme.of(context).primaryColor), // Person icon.
              ),
              const SizedBox(height: 20), // Vertical spacing.

              // Display the current user's email.
              Text(
                currentUser!.email ?? 'No Email', // Fallback if email is null (shouldn't happen for logged in users)
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),

              // TextFormField for editing the display name.
              TextFormField(
                controller: _displayNameController,
                decoration: const InputDecoration(
                  labelText: 'Display Name',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person_outline),
                ),
                validator: (value) {
                  // Validation for display name.
                  if (value == null || value.isEmpty) {
                    return 'Display name cannot be empty.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // Button to save profile changes.
              ElevatedButton.icon(
                // Disable button if an update is already in progress.
                onPressed: _isUpdating ? null : _saveProfile,
                icon: _isUpdating
                    ? const SizedBox( // Show a circular progress indicator when updating.
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                )
                    : const Icon(Icons.save), // Save icon.
                label: Text(_isUpdating ? 'Saving Profile...' : 'Save Profile'), // Button text.
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50), // Make button full width.
                ),
              ),
              const SizedBox(height: 40), // Vertical spacing.

              // Section header for changing password.
              Text(
                'Change Password',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Theme.of(context).primaryColor),
              ),
              const SizedBox(height: 20),

              // TextFormField for entering current password (for reauthentication).
              TextFormField(
                controller: _currentPasswordController,
                obscureText: true, // Hide password input.
                decoration: const InputDecoration(
                  labelText: 'Current Password (for verification)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock_outline),
                ),
              ),
              const SizedBox(height: 15),

              // TextFormField for entering the new password.
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'New Password',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.vpn_key),
                ),
                validator: (value) {
                  // Validation for new password length.
                  if (value != null && value.isNotEmpty && value.length < 6) {
                    return 'Password must be at least 6 characters.';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // Button to change password.
              ElevatedButton.icon(
                onPressed: _isUpdating ? null : _changePassword,
                icon: _isUpdating
                    ? const SizedBox( // Show progress indicator when changing password.
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                )
                    : const Icon(Icons.vpn_key_outlined), // Password key icon.
                label: Text(_isUpdating ? 'Changing Password...' : 'Change Password'), // Button text.
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  backgroundColor: Colors.redAccent, // Distinct color for password button.
                ),
              ),
              const SizedBox(height: 20),

              // Display error message if present.
              if (_errorMessage != null)
                Text(
                  _errorMessage!,
                  style: const TextStyle(color: Colors.red, fontSize: 16),
                  textAlign: TextAlign.center,
                ),
            ],
          ),
        ),
      ),
    );
  }
}