// lib/pages/add_recipes.dart

// Firebase Firestore library for database operations (adding/updating recipes).
import 'package:cloud_firestore/cloud_firestore.dart';
// Firebase Authentication library for getting the current user's ID.
import 'package:firebase_auth/firebase_auth.dart';
// Core Flutter material design library for building UI.
import 'package:flutter/material.dart';

/// A StatefulWidget for adding new recipes or editing existing ones.
/// It accepts optional parameters for `documentId`, `userName`, `description`, and `isEditing`
/// to pre-populate fields when editing.
class AddRecipes extends StatefulWidget {
  final String? documentId; // The ID of the recipe document if editing an existing recipe.
  final String? userName; // The current name of the recipe, used for pre-filling when editing.
  final String? description; // The current description of the recipe, used for pre-filling when editing.
  final bool isEditing; // A flag to determine if the page is in 'edit' mode or 'add' mode.

  const AddRecipes({
    super.key,
    this.documentId,
    this.userName,
    this.description,
    this.isEditing = false, // Defaults to false (add mode).
  });

  @override
  State<AddRecipes> createState() => _AddRecipesState();
}

/// The State class for AddRecipes.
class _AddRecipesState extends State<AddRecipes> {
  // Firebase Authentication instance to get the current user.
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // Firebase Firestore instance to interact with the 'recipes' collection.
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // GlobalKey to uniquely identify the Form widget and enable form validation methods.
  final _formKey = GlobalKey<FormState>();

  // Text editing controllers for the recipe name and description input fields.
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  // Boolean flag to manage the loading state of the UI (e.g., showing a progress indicator during save).
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // If the page is in editing mode, pre-populate the text fields with existing recipe data.
    if (widget.isEditing) {
      _usernameController.text = widget.userName ?? '';
      _descriptionController.text = widget.description ?? '';
    }
  }

  @override
  void dispose() {
    // Dispose of the text editing controllers when the widget is removed from the tree.
    // This frees up resources and prevents memory leaks.
    _usernameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  /// Asynchronously handles saving a new recipe or updating an existing one.
  /// It performs form validation, gets current user ID, and interacts with Firestore.
  Future<void> _saveRecipe() async {
    // Validate all form fields. If validation fails, stop the save process.
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Set loading state to true to indicate that an operation is in progress.
    setState(() {
      _isLoading = true;
    });

    try {
      // Get the currently authenticated user.
      final User? user = _auth.currentUser;
      // If no user is logged in, display an error message and stop.
      if (user == null) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('You must be logged in to add recipes.'), backgroundColor: Colors.red),
          );
        }
        return;
      }

      // Prepare the recipe data as a Map.
      final recipeData = {
        'username': _usernameController.text.trim(), // Trim whitespace from the recipe name.
        'description': _descriptionController.text.trim(), // Trim whitespace from the description.
        'userId': user.uid, // Store the Firebase User ID of the creator for ownership.
        'timestamp': FieldValue.serverTimestamp(), // Add a server-generated timestamp for creation/last update.
      };

      // Check if the page is in editing mode and if a documentId is provided.
      if (widget.isEditing && widget.documentId != null) {
        // If editing, update the existing recipe document in Firestore.
        // SetOptions(merge: true) is used to update only specified fields, leaving others intact.
        // This is particularly useful if old documents don't have a 'userId' and you want to add it.
        await _firestore.collection('recipes').doc(widget.documentId).set(
          recipeData,
          SetOptions(merge: true),
        );
        // Show a success message.
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recipe updated successfully!'), backgroundColor: Colors.green),
          );
        }
      } else {
        // If not editing, add a new recipe document to the 'recipes' collection.
        await _firestore.collection('recipes').add(recipeData);
        // Show a success message.
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recipe added successfully!'), backgroundColor: Colors.green),
          );
        }
      }

      // After successful save/update, navigate back to the previous page (e.g., HomePage).
      if (mounted) {
        Navigator.pop(context);
      }
    } catch (e) {
      // Catch any errors during the Firestore operation and display an error message.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save recipe: $e'), backgroundColor: Colors.red),
        );
      }
      print('Error saving recipe: $e'); // Log the error to console for debugging.
    } finally {
      // This block always executes, regardless of success or failure.
      // Set loading state back to false.
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar for the Add/Edit Recipe page.
      appBar: AppBar(
        title: Text(widget.isEditing ? 'Edit Recipe' : 'Add Recipe'), // Title changes based on mode.
        centerTitle: true, // Centers the title.
      ),
      body: SingleChildScrollView(
        // Allows the content to scroll if the keyboard or content exceeds screen height.
        padding: const EdgeInsets.all(16.0), // Padding around the content.
        child: Form(
          key: _formKey, // Associate the GlobalKey with the Form for validation.
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch, // Stretch children horizontally.
            children: [
              // TextFormField for entering the recipe name.
              TextFormField(
                controller: _usernameController, // Links to the _usernameController.
                decoration: InputDecoration(
                  labelText: 'Recipe Name',
                  hintText: 'e.g., Delicious Pasta',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), // Rounded border.
                  prefixIcon: const Icon(Icons.food_bank), // Icon indicating food.
                ),
                validator: (value) {
                  // Validator for the recipe name field.
                  if (value == null || value.isEmpty) {
                    return 'Please enter a recipe name.'; // Error if empty.
                  }
                  return null; // No error.
                },
              ),
              const SizedBox(height: 20), // Vertical spacing.

              // TextFormField for entering the recipe description.
              TextFormField(
                controller: _descriptionController, // Links to the _descriptionController.
                decoration: InputDecoration(
                  labelText: 'Description',
                  hintText: 'e.g., A quick and easy pasta recipe...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), // Rounded border.
                  prefixIcon: const Icon(Icons.description), // Icon for description.
                ),
                maxLines: 5, // Allows multiple lines for description.
                validator: (value) {
                  // Validator for the description field.
                  if (value == null || value.isEmpty) {
                    return 'Please enter a description.'; // Error if empty.
                  }
                  return null; // No error.
                },
              ),
              const SizedBox(height: 30), // Vertical spacing.

              // Save/Update Recipe button.
              _isLoading
                  ? const Center(child: CircularProgressIndicator()) // Show loading indicator when _isLoading is true.
                  : ElevatedButton.icon(
                onPressed: _saveRecipe, // Calls the _saveRecipe method on press.
                icon: Icon(widget.isEditing ? Icons.update : Icons.add), // Icon changes based on mode.
                label: Text(widget.isEditing ? 'Update Recipe' : 'Add Recipe'), // Text changes based on mode.
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10), // Rounded corners for the button.
                  ),
                  textStyle: const TextStyle(fontSize: 18), // Text style for the button's label.
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}