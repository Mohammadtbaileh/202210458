// lib/pages/login_page.dart

// Firebase Authentication library for handling user login and authentication.
import 'package:firebase_auth/firebase_auth.dart';
// Core Flutter material design library for building UI.
import 'package:flutter/material.dart';

// Import custom pages for navigation.
import 'package:recipe_app/pages/home_page.dart'; // Destination after successful login.
import 'package:recipe_app/pages/signup_page.dart'; // Link to the sign-up page.

/// A StatefulWidget for the user login interface.
/// It allows users to log in with their email and password.
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

/// The State class for LoginPage.
class _LoginPageState extends State<LoginPage> {
  // Firebase Authentication instance to interact with user authentication services.
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Text editing controllers for capturing user input from email and password fields.
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // GlobalKey to uniquely identify the Form widget and enable form validation methods.
  final _formKey = GlobalKey<FormState>();

  // Boolean flag to manage the loading state of the UI (e.g., showing a progress indicator).
  bool _isLoading = false;
  // String to store and display any error messages encountered during login.
  String? _errorMessage;

  @override
  void dispose() {
    // Dispose of the text editing controllers when the widget is removed from the tree.
    // This frees up resources and prevents memory leaks.
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  /// Asynchronously handles the user login process.
  /// It validates input, calls Firebase Authentication, and handles success/failure.
  Future<void> _login() async {
    // Validate all form fields. If validation fails, stop the login process.
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Set loading state to true to indicate that an operation is in progress.
    setState(() {
      _isLoading = true;
      _errorMessage = null; // Clear any previous error messages.
    });

    try {
      // Attempt to sign in the user with the provided email and password.
      // .trim() is used to remove any leading/trailing whitespace from input.
      await _auth.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      // Check if the widget is still mounted before performing UI operations.
      // This prevents errors if the user navigates away rapidly.
      if (mounted) {
        // On successful login, navigate to the HomePage.
        // pushAndRemoveUntil ensures that all previous routes are removed from the stack,
        // preventing the user from going back to the login/signup pages using the back button.
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const HomePage()),
              (Route<dynamic> route) => false, // Predicate that returns false for all routes to pop them.
        );
        // Show a success message using a SnackBar.
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Logged in successfully!'), backgroundColor: Colors.green),
        );
      }
    } on FirebaseAuthException catch (e) {
      // Catch specific Firebase Authentication exceptions and provide user-friendly messages.
      String message;
      if (e.code == 'user-not-found') {
        message = 'No user found for that email.';
      } else if (e.code == 'wrong-password') {
        message = 'Wrong password provided for that user.';
      } else if (e.code == 'invalid-email') {
        message = 'The email address is not valid.';
      } else if (e.code == 'invalid-credential') {
        // This code is more generic for failed login attempts (e.g., email/password mismatch).
        message = 'Invalid email or password.';
      } else {
        // Fallback for any other Firebase Auth error.
        message = e.message ?? 'An unknown error occurred during login.';
      }
      // Set the error message to be displayed on the UI.
      setState(() {
        _errorMessage = message;
      });
    } catch (e) {
      // Catch any other unexpected errors that are not FirebaseAuthException.
      setState(() {
        _errorMessage = 'An unexpected error occurred: $e';
      });
      print('Login error: $e'); // Log the error to console for debugging.
    } finally {
      // This block always executes, regardless of try/catch outcome.
      // Set loading state back to false.
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar for the login page.
      appBar: AppBar(
        title: const Text('Login'), // Title of the app bar.
        centerTitle: true, // Centers the title.
      ),
      body: Center(
        // Centers the content vertically and horizontally.
        child: SingleChildScrollView(
          // Allows the content to scroll if it exceeds screen height (useful for small screens/keyboards).
          padding: const EdgeInsets.all(24.0), // Padding around the scrollable content.
          child: Form(
            key: _formKey, // Associate the GlobalKey with the Form for validation.
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center, // Centers widgets vertically within the column.
              children: [
                // Application icon (e.g., a restaurant menu icon for a recipe app).
                Icon(
                  Icons.restaurant_menu,
                  size: 100, // Large size for visibility.
                  color: Theme.of(context).primaryColor, // Uses the app's primary theme color.
                ),
                const SizedBox(height: 30), // Vertical spacing.

                // Welcome text for the application.
                Text(
                  'Welcome to Recipe Book',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    // Uses the theme's titleLarge text color, adapting to light/dark mode.
                    color: Theme.of(context).textTheme.titleLarge?.color,
                  ),
                ),
                const SizedBox(height: 30), // Vertical spacing.

                // Email input field.
                TextFormField(
                  controller: _emailController, // Links to the email TextEditingController.
                  keyboardType: TextInputType.emailAddress, // Optimized keyboard for email input.
                  decoration: InputDecoration(
                    labelText: 'Email', // Label for the input field.
                    hintText: 'Enter your email', // Placeholder text.
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)), // Rounded border.
                    prefixIcon: const Icon(Icons.email), // Email icon.
                  ),
                  validator: (value) {
                    // Validator for the email field.
                    if (value == null || value.isEmpty) {
                      return 'Please enter your email.'; // Error if empty.
                    }
                    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                      return 'Please enter a valid email address.'; // Error if format is invalid.
                    }
                    return null; // No error.
                  },
                ),
                const SizedBox(height: 20), // Vertical spacing.

                // Password input field.
                TextFormField(
                  controller: _passwordController, // Links to the password TextEditingController.
                  obscureText: true, // Hides the input text (for passwords).
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    prefixIcon: const Icon(Icons.lock), // Lock icon.
                  ),
                  validator: (value) {
                    // Validator for the password field.
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password.'; // Error if empty.
                    }
                    if (value.length < 6) {
                      return 'Password must be at least 6 characters.'; // Error if too short.
                    }
                    return null; // No error.
                  },
                ),
                const SizedBox(height: 30), // Vertical spacing.

                // Login button.
                _isLoading
                    ? const CircularProgressIndicator() // Show loading indicator if _isLoading is true.
                    : ElevatedButton.icon(
                  onPressed: _login, // Calls the _login method on press.
                  icon: const Icon(Icons.login), // Login icon.
                  label: const Text('Login'), // Button text.
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50), // Makes button full width and a fixed height.
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10), // Rounded corners for the button.
                    ),
                    textStyle: const TextStyle(fontSize: 18), // Text style for the button's label.
                  ),
                ),
                const SizedBox(height: 20), // Vertical spacing.

                // Display error message if _errorMessage is not null.
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 15.0),
                    child: Text(
                      _errorMessage!, // Displays the error message.
                      style: const TextStyle(color: Colors.red, fontSize: 14), // Red text for errors.
                      textAlign: TextAlign.center, // Center align error text.
                    ),
                  ),

                // Link to the sign-up page for new users.
                TextButton(
                  onPressed: () {
                    // Navigate to the SignUpPage.
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const SignUpPage()),
                    );
                  },
                  child: const Text("Don't have an account? Sign Up"), // Text for the sign-up link.
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}