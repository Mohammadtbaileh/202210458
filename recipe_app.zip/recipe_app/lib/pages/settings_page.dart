// lib/pages/settings_page.dart

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart'; // Import Provider
import 'package:recipe_app/providers/theme_provider.dart'; // Import your ThemeProvider
import 'package:recipe_app/pages/login_page.dart'; // For logout navigation
import 'package:recipe_app/pages/home_page.dart'; // For home navigation in app bar

class SettingsPage extends StatefulWidget {
  // Removed parameters as we'll now use Provider for theme state
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _notificationsEnabled = true; // Placeholder for notifications setting

  // Handles user logout
  void _logout() async {
    try {
      await _auth.signOut();
      if (mounted) {
        // Navigate back to login page and remove all previous routes from the stack
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LoginPage()),
              (Route<dynamic> route) => false, // This predicate ensures all routes are removed
        );
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Logged out successfully.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error logging out: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Access the ThemeProvider to get and control the current theme mode
    final themeProvider = Provider.of<ThemeProvider>(context);
    final bool isDarkMode = themeProvider.themeMode == ThemeMode.dark;

    // Define gradient colors for the background, adapting to the current theme mode
    final gradientColors = isDarkMode
        ? [Colors.grey[850]!, Colors.redAccent.shade700] // Darker grey to deep redAccent for dark mode
        : [Colors.blue, Colors.lightBlueAccent.shade100]; // Blue to light blue for light mode

    // Define text and icon colors for better contrast and consistency across themes
    final textColor = isDarkMode ? Colors.white70 : Colors.black87;
    final iconColor = isDarkMode ? Colors.redAccent : Colors.blueAccent;

    return Scaffold(
      // AppBar for the settings page
      appBar: AppBar(
        // Set background to transparent and elevation to 0 to let the body's gradient show through
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'Settings',
          style: TextStyle(color: textColor), // Adjust title color dynamically
        ),
        centerTitle: false, // Align title to the left
        actions: [
          IconButton(
            icon: Icon(
              Icons.home,
              color: textColor, // Icon color matches text for consistency
            ),
            onPressed: () {
              // Navigate back to HomePage, replacing the current route
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(
                  builder: (_) => const HomePage(), // HomePage no longer takes userEmail param
                ),
              );
            },
          )
        ],
      ),

      // The body is wrapped in a Container with a BoxDecoration for the gradient background
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea( // Ensures content is not obscured by system UI (e.g., notches, status bar)
          child: ListView( // Use ListView to make the content scrollable if it overflows
            children: [
              // Dark Mode Switch (uses ThemeProvider)
              SwitchListTile(
                title: Text('Dark Mode', style: TextStyle(color: textColor)),
                subtitle: Text(isDarkMode ? 'Enabled' : 'Disabled',
                    style: TextStyle(color: textColor.withOpacity(0.7))),
                value: isDarkMode,
                onChanged: (val) {
                  themeProvider.toggleTheme(val); // Use themeProvider to toggle the theme
                },
                secondary: Icon(
                  isDarkMode ? Icons.dark_mode : Icons.light_mode, // Icon changes with mode
                  color: iconColor,
                ),
              ),

              // Enable Notifications Switch (placeholder functionality)
              SwitchListTile(
                title: Text('Enable Notifications', style: TextStyle(color: textColor)),
                subtitle: Text('Receive app notifications',
                    style: TextStyle(color: textColor.withOpacity(0.7))),
                value: _notificationsEnabled,
                onChanged: (val) {
                  setState(() {
                    _notificationsEnabled = val; // Update local state for this switch
                  });
                },
                secondary: Icon(Icons.notifications, color: iconColor),
              ),

              // About Section (shows app information)
              ListTile(
                leading: Icon(Icons.info_outline, color: iconColor),
                title: Text('About', style: TextStyle(color: textColor)),
                subtitle: Text('Version 1.0.0',
                    style: TextStyle(color: textColor.withOpacity(0.7))),
                onTap: () {
                  showAboutDialog(
                    context: context,
                    applicationName: 'Recipe Book', // Your application's name
                    applicationVersion: '1.0.0',
                    applicationIcon: Icon(Icons.restaurant_menu, color: Theme.of(context).primaryColor), // Icon with primary theme color
                    children: const [
                      Text('A simple app to manage your recipes.') // Brief app description
                    ],
                  );
                },
              ),
              Divider(color: textColor.withOpacity(0.5)), // A divider for visual separation

              // Logout Option
              ListTile(
                leading: Icon(Icons.logout, color: iconColor),
                title: Text('Logout', style: TextStyle(color: textColor)),
                onTap: _logout, // Calls the logout function
              ),
            ],
          ),
        ),
      ),
    );
  }
}