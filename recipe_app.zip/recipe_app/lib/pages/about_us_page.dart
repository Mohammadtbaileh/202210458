// lib/pages/about_us_page.dart

// Core Flutter material design library for building UI.
import 'package:flutter/material.dart';

/// A StatelessWidget representing the "About Us" page of the application.
/// It provides information about the app's purpose, features, and developers.
class AboutUsPage extends StatelessWidget {
  const AboutUsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar for the "About Us" page.
      appBar: AppBar(
        title: const Text('About Us'), // Title of the app bar.
        centerTitle: true, // Centers the title.
      ),
      body: SingleChildScrollView(
        // Allows the content to scroll if it exceeds screen height.
        padding: const EdgeInsets.all(20.0), // Padding around the content.
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center, // Centers children horizontally.
          children: <Widget>[
            // App Logo or Icon.
            // This uses a built-in Flutter icon. You can replace it with an actual app logo (Image.asset, Image.network)
            // if you decide to include image assets later.
            const Icon(
              Icons.restaurant_menu, // Example icon relevant to a recipe app.
              size: 80, // Size of the icon.
              color: Colors.blueAccent, // Color of the icon.
            ),
            const SizedBox(height: 20), // Vertical spacing.

            // App Name/Welcome message.
            Text(
              'Welcome to Recipe Book!',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).primaryColor, // Uses the app's primary theme color.
              ),
              textAlign: TextAlign.center, // Center align the text.
            ),
            const SizedBox(height: 15), // Vertical spacing.

            // App Tagline/Mission statement.
            const Text(
              'Your ultimate companion for culinary adventures.',
              style: TextStyle(
                fontSize: 18,
                fontStyle: FontStyle.italic, // Italicize the tagline.
                color: Colors.grey, // Grey color for a subtle look.
              ),
              textAlign: TextAlign.center, // Center align the text.
            ),
            const SizedBox(height: 30), // Vertical spacing.

            // Main "About Us" content/description.
            Text(
              'Recipe Book is designed to be your personal digital cookbook. '
                  'Whether you\'re a seasoned chef or just starting your cooking journey, '
                  'our app provides a simple and intuitive way to save, organize, '
                  'and share your favorite recipes.',
              style: const TextStyle(fontSize: 16, height: 1.5), // Font size and line height.
              textAlign: TextAlign.justify, // Justify text for a clean block look.
            ),
            const SizedBox(height: 15), // Vertical spacing.
            Text(
              'We believe that great food brings people together. '
                  'With Recipe Book, you can easily access your culinary creations '
                  'anytime, anywhere. Add new recipes with ' // Note: Removed "photos" as per "no images" request.
                  'detailed descriptions, and ingredients, then share them with friends and family.',
              style: const TextStyle(fontSize: 16, height: 1.5),
              textAlign: TextAlign.justify,
            ),
            const SizedBox(height: 30), // Vertical spacing.

            // Contact/Developer Info.
            Text(
              'Developed with passion by [Mohammad Tbaileh,Malek Al Khaleel].', // Developer names.
              style: const TextStyle(fontSize: 14, color: Colors.black54), // Smaller, slightly faded text.
              textAlign: TextAlign.center, // Center align.
            ),
            const SizedBox(height: 5), // Vertical spacing.
            Text(
              '© 2025 Recipe Book. All rights reserved.', // Copyright notice.
              style: const TextStyle(fontSize: 12, color: Colors.black45), // Smaller, more faded text.
              textAlign: TextAlign.center, // Center align.
            ),
          ],
        ),
      ),
    );
  }
}