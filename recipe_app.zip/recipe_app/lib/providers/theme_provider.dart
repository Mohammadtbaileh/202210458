// lib/providers/theme_provider.dart
import 'package:flutter/material.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system; // Default to system theme setting

  ThemeMode get themeMode => _themeMode; // Getter to access the current theme mode

  // Toggles the theme between dark and light mode based on a boolean value.
  // 'isDarkMode' true sets to dark, false sets to light.
  void toggleTheme(bool isDarkMode) {
    _themeMode = isDarkMode ? ThemeMode.dark : ThemeMode.light;
    notifyListeners(); // Notify all widgets that are listening to this provider about the change
  }

  // Explicitly sets the theme mode to a specific ThemeMode value (e.g., ThemeMode.dark, ThemeMode.light, ThemeMode.system).
  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    notifyListeners(); // Notify listeners
  }
}